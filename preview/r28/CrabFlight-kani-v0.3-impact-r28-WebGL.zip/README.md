# カニとばし r28 試遊（未合格・未確認あり）
著作権はさきや（独自コード）。第三者素材・voice/は各CREDITS.md、licenses/、voice/NOTICE.mdを参照。配信・動画はご自由にどうぞ。配信・動画では「VOICEVOX:ずんだもん」の表記をお願いします。

r27cと正式トップは比較・復帰用に保持。r27試遊の進捗と設定を引き継ぎ、正式版の保存領域とは分離します。材質別破片、命中輪郭、残像、接触文字を改修した候補です。40投・物理iPhone・実聴・最終ゲートは未完で、完成や本人採用を意味しません。

Local start: unzip, cd to the extracted folder, run python3 -m http.server 8034 --bind 127.0.0.1 and open http://127.0.0.1:8034/ . A file:// URL cannot start Unity WebGL. No installer is run.
