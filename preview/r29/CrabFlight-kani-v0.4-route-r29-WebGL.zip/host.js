'use strict';
let lastReclaimR12=0;
document.body.dataset.wrapperRevision='kani-v0.4-route-r29';
const $=id=>document.getElementById(id),RULE='crab-r21-floor-first-audit1',RECORD='crab-flight-r21-floor-first-audit1-record',PREF='crab-flight-ceiling-r9';
const config={angle:40,power:70,claw:45,shell:45,legs:45,direction:1,spinRps:0},comfort={volume:65,reduced:!!(window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches)};
let pendingPrepareR23=0,prepareToAimR23=false,inputSequenceR23=0;const inputLogR23=[];
let game=null,runtimeReady=false,loaded=false,view='loading',phase='ready',resumeView='aim',optionsBack='title',savedBest=0,oldBest=0,oldR9Best=0,lastEvent=-1,lastResult=-1,lastMissCount=0,lastDestruction=0,feedbackTimer=null,recordTimer=null,spaceHeld=false,kickPointer=null,sentHeld=false,lastState=null;
const gesture=new window.FlightLaunch.PointerSwipe();let chargePath=0,chargeAt=0;
function addChargeWork(r){const now=r.sampleTime;const dt=(now-chargeAt)/1000,travel=Math.max(0,r.path-chargePath)/Math.max(100,Math.min(innerWidth,innerHeight));if(dt>0)send('AddSpinWork',JSON.stringify({distance:travel,seconds:dt,direction:r.direction}));chargeAt=now;chargePath=r.path;}
function safe(v,min,max,fallback){v=Number(v);return Number.isFinite(v)?Math.min(max,Math.max(min,v)):fallback;}
try{
 const c=JSON.parse(localStorage.getItem(PREF+'-config'));if(c)for(const id of Object.keys(config))config[id]=safe(c[id],id==='angle'?10:id==='direction'?-1:id==='spinRps'?-12:0,id==='angle'?80:id==='direction'?1:id==='spinRps'?12:100,config[id]);
 const cft=JSON.parse(localStorage.getItem(PREF+'-comfort')||localStorage.getItem('crab-flight-momentum-r8-comfort')||localStorage.getItem('crab-flight-impact-core-r7-comfort')||localStorage.getItem('crab-flight-city2-comfort')||localStorage.getItem('crab-flight-kick-r1-comfort')||localStorage.getItem('crab-flight-r1-comfort'));if(cft){comfort.volume=safe(cft.volume,0,100,65);if(typeof cft.reduced==='boolean')comfort.reduced=cft.reduced;}
 const record=JSON.parse(localStorage.getItem(RECORD));if(record&&record.ruleVersion===RULE)savedBest=safe(record.best,0,10000,0);
 oldBest=safe(localStorage.getItem('crab-flight-r1-best'),0,10000,0);
 const r9=JSON.parse(localStorage.getItem('crab-flight-ceiling-r9-record'));if(r9&&r9.ruleVersion==='crab-ceiling-r9')oldR9Best=safe(r9.best,0,10000,0);
}catch{}
// This comparison uses a fixed crab; retained custom UI and older saves remain intact.
const FIXED_SHAPE=Object.freeze({claw:45,shell:45,legs:45});
const LOADOUT=window.CrabLoadout;let selectedGear=0,loadoutWritable=true;
try{const raw=localStorage.getItem(LOADOUT.key);if(raw!==null){const v=JSON.parse(raw);if(v?.version===1&&Number.isInteger(v.gear)&&v.gear>=0&&v.gear<LOADOUT.kits.length)selectedGear=v.gear;else loadoutWritable=false;}}catch{loadoutWritable=false;}
Object.assign(config,FIXED_SHAPE);
const P=window.CrabProgression,pageSession=crypto.randomUUID();
let progressLoaded;try{progressLoaded=P.read(localStorage.getItem(P.STORAGE_KEY));}catch{progressLoaded={state:P.create(),canWrite:false,status:'storage-unavailable'};}
if(!navigator.locks)progressLoaded.canWrite=false;
let progress=progressLoaded.state,earnedThisRun=0,purchaseLevel=null,purchaseUnlockAt=0,purchasePending=false;
function saveProgress(){if(progressLoaded.canWrite)try{localStorage.setItem(P.STORAGE_KEY,P.serialize(progress));}catch{progressLoaded.canWrite=false;}}
function activeLoadout(){return LOADOUT.kits[selectedGear].level<=progress.level?LOADOUT.kits[selectedGear]:LOADOUT.kits[0];}
function loadoutUI(){const active=activeLoadout();$('gearSummary').textContent=active.name+' · 強化Lv.'+progress.level;const next=LOADOUT.kits.find(k=>k.level>progress.level);$('gearProgress').textContent='所持 '+progress.coins+' 🪙 ／ 射出 +'+progress.level*4+'%'+(progress.level>=2?'・天井突破':'' )+(next?' ／ 次はLv.'+next.level+'で'+next.name:' ／ 全装備解放');for(const kit of LOADOUT.kits){const b=$('gear'+kit.id);b.disabled=kit.level>progress.level||!!pendingPrepareR23||!loadoutWritable;b.setAttribute('aria-pressed',String(kit.id===active.id));b.textContent=kit.name+(kit.level>progress.level?' · Lv.'+kit.level+'で解放':'');}$('gearDescription').textContent=active.description+(loadoutWritable?'':' 装備の記録が保存できないため変更を止めています。');}
function chooseGear(id){if(view!=='custom'||pendingPrepareR23||!loadoutWritable||LOADOUT.kits[id].level>progress.level)return;selectedGear=id;try{localStorage.setItem(LOADOUT.key,JSON.stringify({version:1,gear:id}));}catch{loadoutWritable=false;}configure();loadoutUI();window.FlightSound.play('adjust');}
for(const kit of LOADOUT.kits)$('gear'+kit.id).onclick=()=>chooseGear(kit.id);
function growthUI(){const cost=P.nextCost(progress);$('coinResult').textContent=progressLoaded.canWrite?'+'+earnedThisRun+' 🪙　'+progress.coins+' 🪙':'成長記録を確認できません';$('upgrade').textContent=cost===null?'打ち出し MAX':'強化Lv.'+(progress.level+1)+' · 射出+'+((progress.level+1)*4)+'%'+(progress.level===1?'・天井突破':'・装備解放')+'　'+cost+' 🪙';$('upgrade').disabled=!progressLoaded.canWrite||cost===null||progress.coins<cost||clock()<purchaseUnlockAt;purchaseLevel=progress.level;loadoutUI();}
function refreshProgress(){try{const latest=P.read(localStorage.getItem(P.STORAGE_KEY));if(!latest.canWrite){progressLoaded.canWrite=false;return false;}progress=latest.state;return progressLoaded.canWrite;}catch{progressLoaded.canWrite=false;return false;}}
window.addEventListener('storage',e=>{if(e.key===P.STORAGE_KEY){refreshProgress();growthUI();}});
async function settleProgress(s){if(!navigator.locks){growthUI();return;}return navigator.locks.request(P.STORAGE_KEY,{mode:'exclusive'},()=>{if(!refreshProgress()){growthUI();return;}const out=P.settle(progress,{session:pageSession,generation:s.generation,attempt:s.attempts,finished:s.phase==='result',phase:s.phase,physicsFault:s.physicsFault,distance:s.distance,destructionCount:s.destructionEvent});if(out.status!=='duplicate-or-stale'){progress=out.state;earnedThisRun=out.earned||0;saveProgress();}growthUI();});}
$('upgrade').onclick=async()=>{if(view!=='result'||phase!=='result'||!progressLoaded.canWrite||$('upgrade').disabled)return;const expected=purchaseLevel,expectedAttempt=lastState?.attempts,expectedGeneration=lastState?.generation;purchasePending=true;$('upgrade').disabled=true;$('retry').disabled=$('prepare').disabled=true;if(!navigator.locks){purchasePending=false;$('retry').disabled=$('prepare').disabled=false;return;}return navigator.locks.request(P.STORAGE_KEY,{mode:'exclusive'},()=>{if(view!=='result'||phase!=='result'||lastState?.attempts!==expectedAttempt||lastState?.generation!==expectedGeneration||!refreshProgress()){growthUI();return;}const out=P.purchase(progress,{expectedLevel:expected});if(out.status==='purchased'){progress=out.state;purchaseUnlockAt=clock()+650;setTimeout(growthUI,660);saveProgress();send('SetUpgradeLevel',String(progress.level));window.FlightSound.play('adjust');}growthUI();}).finally(()=>{purchasePending=false;$('retry').disabled=$('prepare').disabled=false;});};
let boostUntil=0;
let lastBurstCount=0;let lastRoofExitAttempt=-1;let oldKick=0;try{const k=JSON.parse(localStorage.getItem('crab-flight-kick-r1-record'));if(k&&k.ruleVersion==='crab-kick-r1')oldKick=safe(k.best,0,10000,0);}catch{}
$('legacyBest').textContent=(oldR9Best>0?'r9記録 '+oldR9Best.toFixed(1)+' m。':'')+(oldBest>0?'旧・初着地 '+oldBest.toFixed(1)+' m。':'')+(oldKick>0?'旧キック版 '+oldKick.toFixed(1)+' m。':'')+((oldR9Best>0||oldBest>0||oldKick>0)?'別記録として保持。':'');
// Public runtime excludes diagnostic collection and query switches.
const clock=()=>typeof performance!=='undefined'?performance.now():Date.now();
function stampInput(){}
const acknowledgedR23=new Set(['Prepare','Configure','BeginSpinCharge','AddSpinWork','BeginAim','PreviewLaunch','CancelAim','ReleaseLaunch','RetryLaunch','SetUpgradeLevel']);
function send(method,value=''){
 if(!game)return 0;
 if(!acknowledgedR23.has(method)){game.SendMessage('CrabFlightGame',method,String(value));return 0;}
 const id=++inputSequenceR23,entry={id,method,payload:String(value),sentAt:clock(),wrapperRevision:document.body.dataset.wrapperRevision,generation:lastState?.generation,phase:lastState?.phase};
 entry.key=pageSession+'-'+id;inputLogR23.push(entry);persistInputR23(entry);
 if(method==='Prepare'){pendingPrepareR23=id;lastState=null;document.body.dataset.inputPending='true';}
 game.SendMessage('CrabFlightGame','ReceiveInputR23',JSON.stringify({id,method,payload:String(value)}));return id;
}
window.readInputReceiptsR23=()=>inputLogR23.map(x=>({...x}));
function persistInputR23(entry){auditStoreR21.then(db=>{const tx=db.transaction('commands','readwrite');tx.objectStore('commands').put(entry);tx.onerror=()=>{document.body.dataset.inputReceipt='storage-error';};},()=>{document.body.dataset.inputReceipt='storage-unavailable';});}
function persist(){try{localStorage.setItem(PREF+'-config',JSON.stringify(config));}catch{}}
function numbers(c=config){$('angleValue').textContent=(c.direction<0?'↖ ':'↗ ')+Math.round(c.angle)+'°';$('powerValue').textContent=Math.round(c.power);$('spinValue').textContent=(c===config&&!gesture.active?(view==='aim'&&lastState?.chargeStarted?Math.abs(lastState.spinRps||0):0):Math.abs(c.spinRps||0)).toFixed(1);$('powerFill').style.width=c.power+'%';}
function eventTime(e){return Number.isFinite(e.timeStamp)?e.timeStamp:clock();}
function swipePayload(r){return JSON.stringify({angle:r.angle,power:r.power,direction:r.direction,spinRps:r.spinRps,spinPhase:r.spinPhase||0,eligible:r.valid!==false});}
function cancelRecord(){if(recordTimer!==null){clearTimeout(recordTimer);recordTimer=null;}}
function inputHeld(){send(view==='flight'&&(spaceHeld||kickPointer!==null)?'KickDown':'KickUp');}
function releaseKick(){spaceHeld=false;kickPointer=null;inputHeld();}
function feedback(kind,text){if(window.FlightFeel?.ready()){if(feedbackTimer)clearTimeout(feedbackTimer);feedbackTimer=null;$('kickFeedback').classList.add('hidden');return;}if(feedbackTimer)clearTimeout(feedbackTimer);$('kickFeedback').textContent=text;$('kickFeedback').dataset.kind=kind;$('kickFeedback').classList.remove('hidden');feedbackTimer=setTimeout(()=>{$('kickFeedback').classList.add('hidden');feedbackTimer=null;},650);}
function aimHint(text=''){const hint=$('aimHint');hint.textContent=text;hint.classList.toggle('hidden',!text);}
function setView(next){
 view=next;document.body.dataset.view=next;if(next==='aim'){aimHint();$('helpButton').setAttribute('aria-expanded','false');}
 for(const id of ['loading','title','aimHUD','launchZone','aimActions','flightHUD','kick','result','pauseMenu','custom','options'])$(id).classList.add('hidden');
 for(const id of ({loading:['loading'],error:['loading'],title:['title'],aim:['aimHUD','launchZone','aimActions'],flight:['flightHUD','kick'],result:['result'],pause:['pauseMenu'],custom:['custom'],options:['options']}[next]||[]))$(id).classList.remove('hidden');
 $('pauseButton').classList.toggle('hidden',!['aim','flight','result'].includes(next));
 if(next!=='flight'){$('kickFeedback').classList.add('hidden');$('acceleration').classList.add('hidden');document.body.dataset.accelerating='false';}
 if(next!=='aim'){$('gesture').classList.add('hidden');$('cancelAim').classList.add('hidden');document.body.dataset.dragging='false';}
 inputHeld();
}
function cancelGesture(reason,clear=true){window.FlightSound.setSpin(0);const r=gesture.cancel(reason,clear);if(r.type==='cancel'){send('CancelAim');numbers();aimHint('取り消しました。もう一度スワイプできます。');}document.body.dataset.dragging='false';$('gesture').classList.add('hidden');$('cancelAim').classList.add('hidden');}
function setPaused(paused){cancelRecord();cancelGesture('pause');releaseKick();send('SetPaused',paused?'1':'0');window.FlightSound.setPaused(paused);}
function pause(){if(!['aim','flight','result'].includes(view))return;resumeView=view;setPaused(true);setView('pause');}
function resume(){if(view!=='pause')return;setPaused(false);setView(resumeView);}
function configure(){Object.assign(config,activeLoadout().shape,{gear:activeLoadout().id,upgradeLevel:progress.level});persist();numbers();return send('Configure',JSON.stringify(config));}
function applyComfort(){ $('volume').value=comfort.volume;$('volumeValue').textContent=comfort.volume+'%';window.FlightSound.setVolume(comfort.volume/100);if(window.FlightFeel)window.FlightFeel.setSettings({});try{localStorage.setItem(PREF+'-comfort',JSON.stringify({volume:comfort.volume}));}catch{}}
function prepare(){if(purchasePending||pendingPrepareR23)return;refreshProgress();cancelRecord();cancelGesture('prepare');releaseKick();window.FlightSound.setPaused(false);prepareToAimR23=true;send('Prepare');send('SetUpgradeLevel',String(progress.level));configure();numbers();}
function openCustom(){if(!['title','aim','result'].includes(view)||(view==='aim'&&lastState?.chargeStarted)||purchasePending)return;if(view==='result')send('Prepare');cancelGesture('custom');setPaused(true);loadoutUI();setView('custom');}
function openOptions(){optionsBack=view;if(view!=='pause')setPaused(true);setView('options');}
$('start').onclick=()=>{if(loaded&&runtimeReady)prepare();};$('prepare').onclick=prepare;$('customButton').onclick=$('resultCustom').onclick=$('titleGear').onclick=openCustom;
$('closeCustom').onclick=()=>{setPaused(false);configure();setView('aim');};$('titleOptions').onclick=$('pauseOptions').onclick=openOptions;
$('closeOptions').onclick=()=>{if(optionsBack!=='pause')setPaused(false);setView(optionsBack);};$('pauseButton').onclick=pause;$('resume').onclick=resume;
$('home').onclick=()=>{cancelRecord();cancelGesture('home');releaseKick();window.FlightSound.setPaused(false);send('Prepare');setView('title');};
$('prepare').onclick=()=>{stampInput();if(view!=='result'||phase!=='result'||purchasePending)return;refreshProgress();cancelRecord();releaseKick();lastEvent=-1;send('SetUpgradeLevel',String(progress.level));send('RetryLaunch');};
$('retry').onclick=prepare;
$('cancelAim').onclick=()=>cancelGesture('button');$('helpButton').onclick=()=>{const expanded=$('helpButton').getAttribute('aria-expanded')!=='true';$('helpButton').setAttribute('aria-expanded',String(expanded));aimHint(expanded?'10秒間、左右に何度もスワイプ。たまったら上に弾いて離す。止めて離すと取消。':'');};
$('sound').onclick=async()=>{const enabled=await window.FlightSound.toggle();$('sound').setAttribute('aria-checked',String(enabled));$('sound').textContent=enabled?'音：オン':'音：オフ';};
$('volume').addEventListener('input',()=>{comfort.volume=safe($('volume').value,0,100,65);applyComfort();});
function protectTouchRange(input){let touch=null;const finish=()=>{touch=null;};input.addEventListener('pointerdown',e=>{if(e.pointerType==='touch')e.preventDefault();});input.addEventListener('touchstart',e=>{if(e.touches.length!==1)return;const t=e.touches[0];touch={x:t.clientX,y:t.clientY,axis:null,accepted:input.value};},{passive:true});input.addEventListener('input',e=>{if(touch){input.value=touch.accepted;e.stopImmediatePropagation();}},true);input.addEventListener('touchmove',e=>{if(!touch||e.touches.length!==1)return;const t=e.touches[0],dx=Math.abs(t.clientX-touch.x),dy=Math.abs(t.clientY-touch.y);if(!touch.axis&&Math.max(dx,dy)>=8)touch.axis=dx>dy?'x':'y';if(touch.axis==='x'){if(e.cancelable)e.preventDefault();const r=input.getBoundingClientRect();input.value=String(Math.round(Number(input.min)+(Number(input.max)-Number(input.min))*Math.min(1,Math.max(0,(t.clientX-r.left)/r.width))));touch.accepted=input.value;input.dispatchEvent(new Event('change'));}},{passive:false});input.addEventListener('touchend',e=>{if(touch&&touch.axis!=='y'&&e.changedTouches.length){const r=input.getBoundingClientRect();input.value=String(Math.round(Number(input.min)+(Number(input.max)-Number(input.min))*Math.min(1,Math.max(0,(e.changedTouches[0].clientX-r.left)/r.width))));input.dispatchEvent(new Event('change'));}finish();},{passive:true});input.addEventListener('touchcancel',finish,{passive:true});}

function drawGesture(r){const attrs=(id,a)=>{for(const [k,v]of Object.entries(a))$(id).setAttribute(k,String(v));};const x=window.innerWidth*.5,y=window.innerHeight*.36,length=35+r.power*.9,norm=Math.max(.01,r.speed);attrs('pullLine',{x1:r.x-r.normalizedVx*18,y1:r.y-r.normalizedVy*18,x2:r.x,y2:r.y});attrs('directionLine',{x1:x,y1:y,x2:x+r.normalizedVx/norm*length,y2:y+r.normalizedVy/norm*length});attrs('pullAnchor',{cx:x,cy:y});attrs('pullHand',{cx:r.x,cy:r.y});$('gesture').classList.remove('hidden');$('gesture').dataset.valid=String(r.valid);}
function gestureResult(r){
 if(r.type==='begin'){chargePath=0;chargeAt=r.sampleTime;send('BeginSpinCharge');document.body.dataset.dragging='true';$('cancelAim').classList.remove('hidden');send('BeginAim');}
 if(r.type==='preview'){addChargeWork(r);numbers(r);drawGesture(r);aimHint(!lastState?.chargeReady||r.valid?'':r.reason==='stale'?'止めたので発射しません。もう一度スワイプ':!r.upward?'上向きに弾こう。下向きには飛ばしません':'もう少し速く、上へスワイプ！');window.FlightSound.setSpin(Math.abs(r.spinRps)/12);send('PreviewLaunch',swipePayload(r));}
 if(r.type==='cancel'){window.FlightSound.setSpin(0);send('CancelAim');numbers();document.body.dataset.dragging='false';$('gesture').classList.add('hidden');$('cancelAim').classList.add('hidden');aimHint(r.reason==='multitouch'?'指1本で操作できます':r.reason==='button'||r.reason==='cancel-target'?'発射を取り消しました':'');}
 if(r.type==='launch'){if(!lastState?.chargeReady){send('CancelAim');document.body.dataset.dragging='false';$('gesture').classList.add('hidden');$('cancelAim').classList.add('hidden');return;}config.angle=r.angle;config.power=r.power;config.direction=r.direction;config.spinRps=r.spinRps;persist();numbers();document.body.dataset.dragging='false';$('gesture').classList.add('hidden');$('cancelAim').classList.add('hidden');send('ReleaseLaunch',swipePayload(r));}
}
window.addEventListener('pointerdown',e=>{
 stampInput(); const zone=$('launchZone'),eligible=view==='aim'&&!pendingPrepareR23&&phase==='ready'&&runtimeReady&&e.button===0&&(e.target===zone||zone.contains(e.target));
 const r=gesture.down(e.pointerId,e.clientX,e.clientY,eligible,Math.max(100,Math.min(window.innerWidth,window.innerHeight)),eventTime(e));
 if(r.type==='begin'){e.preventDefault();zone.focus({preventScroll:true});try{zone.setPointerCapture(e.pointerId);}catch{cancelGesture('capture-failed');return;}}
 gestureResult(r);
},true);
window.addEventListener('pointermove',e=>{stampInput();const r=gesture.move(e.pointerId,e.clientX,e.clientY,e.buttons,eventTime(e));if(r.type!=='ignore'){e.preventDefault();gestureResult(r);}},true);
window.addEventListener('pointerup',e=>{stampInput();const cancelRect=$('cancelAim').getBoundingClientRect(),overCancel=!!gesture.active&&e.clientX>=cancelRect.left&&e.clientX<=cancelRect.right&&e.clientY>=cancelRect.top&&e.clientY<=cancelRect.bottom;if(overCancel)cancelGesture('cancel-target',false);gestureResult(gesture.up(e.pointerId,e.clientX,e.clientY,e.clientX>=0&&e.clientY>=0&&e.clientX<=window.innerWidth&&e.clientY<=window.innerHeight,eventTime(e))); if(e.pointerId===kickPointer){kickPointer=null;inputHeld();}},true);
window.addEventListener('pointercancel',e=>{if(gesture.active&&gesture.active.id===e.pointerId)cancelGesture('pointercancel',false);gesture.up(e.pointerId,NaN,NaN,false,eventTime(e));if(e.pointerId===kickPointer){kickPointer=null;inputHeld();}},true);
$('launchZone').addEventListener('lostpointercapture',()=>cancelGesture('lostcapture',false));
$('launchZone').addEventListener('keydown',e=>{stampInput();if(view!=='aim'||pendingPrepareR23||phase!=='ready'||!runtimeReady)return;if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)){e.preventDefault();cancelGesture('keyboard');if(e.code==='ArrowUp')config.angle=Math.min(80,config.angle+2);if(e.code==='ArrowDown')config.angle=Math.max(10,config.angle-2);if(e.code==='ArrowLeft')config.direction=-1;if(e.code==='ArrowRight')config.direction=1;configure();}if(e.code==='Enter'&&!e.repeat){e.preventDefault();if(!lastState?.chargeReady){send('BeginSpinCharge');send('AddSpinWork',JSON.stringify({distance:.25,seconds:.12,direction:config.direction}));return;}cancelGesture('keyboard-launch');send('BeginAim');send('ReleaseLaunch',JSON.stringify({angle:config.angle,power:config.power,direction:config.direction,spinRps:config.direction*config.power*.12,eligible:true}));}});
$('kick').addEventListener('pointerdown',e=>{if(view!=='flight'||$('kick').disabled)return;e.preventDefault();kickPointer=e.pointerId;inputHeld();});
document.addEventListener('keyup',e=>{if(e.code==='Space'){spaceHeld=false;inputHeld();}});
document.addEventListener('keydown',e=>{if(e.code==='Space'&&view==='flight'&&!e.repeat){e.preventDefault();spaceHeld=true;inputHeld();}if(e.code==='Escape'){if(view==='pause')resume();else if(gesture.active)cancelGesture('escape');else pause();}});
window.addEventListener('blur',()=>{cancelGesture('blur');releaseKick();pause();});document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelGesture('hidden');releaseKick();pause();}});
window.addEventListener('resize',()=>{cancelGesture('resize');releaseKick();if(view==='flight')pause();});
let savedThrowAuditR21='';
const auditStoreR21=new Promise((resolve,reject)=>{const request=indexedDB.open('crab-throw-receipts-r21',2);request.onupgradeneeded=()=>{const db=request.result;if(!db.objectStoreNames.contains('throws'))db.createObjectStore('throws',{keyPath:'id'});if(!db.objectStoreNames.contains('commands'))db.createObjectStore('commands',{keyPath:'key'});};request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});
window.readThrowReceiptsR21=()=>auditStoreR21.then(db=>new Promise((resolve,reject)=>{const q=db.transaction('throws').objectStore('throws').getAll();q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error);}));
window.receiveFlightState=s=>{
 for(const ack of s.inputAcks||[]){const entry=inputLogR23.find(x=>x.id===ack.id),fresh=entry&&!entry.ack;if(fresh){entry.ack=ack;entry.receivedAt=clock();persistInputR23(entry);}
  if(ack.id===pendingPrepareR23&&ack.accepted&&s.phase==='ready'&&!s.chargeStarted){pendingPrepareR23=0;document.body.dataset.inputPending='false';if(prepareToAimR23){prepareToAimR23=false;setView('aim');}}
  if(fresh&&ack.generation===s.generation&&ack.method==='ReleaseLaunch'&&!ack.accepted)aimHint('発射できませんでした · '+ack.reason);
 }

 if(s.throwAudit&&s.throwAudit!==savedThrowAuditR21){savedThrowAuditR21=s.throwAudit;const entry=JSON.parse(s.throwAudit);auditStoreR21.then(db=>{const tx=db.transaction('throws','readwrite');tx.objectStore('throws').put(entry);tx.onerror=()=>{document.body.dataset.throwReceipt='storage-error';};tx.oncomplete=()=>{document.body.dataset.throwReceipt=entry.status;};},()=>{document.body.dataset.throwReceipt='storage-unavailable';});}

 if(window.FlightFeel)window.FlightFeel.update(s);if(window.FlightCues)window.FlightCues.update(s);
 if(window.FlightResult)window.FlightResult.update(s);
 if(window.FlightSound.update)window.FlightSound.update(s);
 $('brand').textContent=s.phase==='flight'?({restaurant:'レストラン',mall:'商業施設',office:'オフィス街',port:'港の市場',viaduct:'高架沿い',country:'広域 · 仮配置',launchrange:'上空 · 仮配置',orbit:'宇宙 · 仮配置',tank:'生簀'}[s.district]||'カニとばし'):'カニとばし · kani-v0.4-route-r29';lastState=s;runtimeReady=s.runtimeReady===true;document.body.dataset.runtimeReady=String(runtimeReady);$('start').disabled=!loaded||!runtimeReady;
 const changed=phase!==s.phase;if(changed)cancelRecord();phase=s.phase;document.body.dataset.phase=phase;document.body.dataset.stage=s.stage;document.body.dataset.runtimeRevision=s.revision;document.body.dataset.ruleVersion=s.ruleVersion;document.body.dataset.ceilingUnlocked=String(!!s.ceilingUnlocked);document.body.dataset.ceilingExited=String(!!s.ceilingExited);document.body.dataset.paused=String(s.paused);document.body.dataset.direction=String(s.direction);document.body.dataset.spinRps=String(s.spinRps);
 if(view==='custom')loadoutUI();if($('customButton'))$('customButton').disabled=!!s.chargeStarted||pendingPrepareR23>0;
 if(loaded&&runtimeReady&&view==='loading')setView('title');
 if(changed){releaseKick();if(phase==='flight'){lastMissCount=0;lastEvent=-1;lastDestruction=0;lastBurstCount=0;lastReclaimR12=0;boostUntil=0;setView('flight');if(!Array.isArray(s.events))window.FlightSound.play('launch');}if(phase==='result'){setView('result');if(s.newRecord)recordTimer=setTimeout(()=>{recordTimer=null;if(view==='result')window.FlightSound.play('record');},100);}}
 $('best').textContent=s.best.toFixed(1)+' m';$('distance').textContent=s.distance.toFixed(1);$('distanceUnit').textContent='m';$('height').textContent=Math.round(s.speed)+' m/s';$('rotorReserve').value=Math.round(100*(s.rotorRemaining||0)/Math.max(1,s.rotorCapacity||1));$('rotorPercent').textContent=$('rotorReserve').value+'%';$('height').setAttribute('aria-label','速さ '+Math.round(s.speed)+' m/s');$('destructionValue').textContent=String(s.destructionEvent);window.FlightSound.setSpin((view==='flight'||gesture.active||s.chargeStarted)?Math.abs(s.spinRps||0)/22:0);$('spinValue').textContent=Math.abs(s.spinRps||0).toFixed(1);$('chargeTime').textContent=s.chargeReady?'発射！':(10-(s.chargeElapsed||0)).toFixed(1)+'s';$('chargeFill').style.width=(Math.min(1,(s.chargeElapsed||0)/10)*100)+'%';$('chargeGauge').setAttribute('aria-valuenow',String(Math.round(Math.min(1,(s.chargeElapsed||0)/10)*100)));$('launchZone').querySelector('span').textContent=s.chargeReady?'上向きに弾いて発射！':'よこスワイプで回す';document.body.dataset.charged=String(!!s.chargeReady);
 const ground=['TUMBLE','SETTLED','RESULT'].includes(s.stage);$('kick').disabled=s.kicksRemaining<=0||ground;$('kick').dataset.braced=String(s.braced);$('kick').setAttribute('aria-label','着地プッシュ、残り'+s.kicksRemaining+'回');$('kickBudget').textContent=ground?'止まるまで見届けよう':s.braced?'構え中！':s.kicksRemaining>0?'補助はあと'+s.kicksRemaining+'回':'使い切った！';
 if(view==='flight'){
  if(s.destructionEvent>lastDestruction){lastDestruction=s.destructionEvent;if(!Array.isArray(s.events))window.FlightSound.play(s.lastBroken.startsWith('tank')?'glass':s.lastBroken.startsWith('dish')?'dish':s.lastBroken.startsWith('wood')?'wood':s.lastBroken.startsWith('metal')?'metal':s.lastBroken.startsWith('food')?'food':'wall');const b=Array.isArray(s.events)?s.events.slice().reverse().find(e=>e.type==='destruction'&&e.objectId===s.lastBroken):null;const id=s.lastBroken,type=b?.material||'';const label=b?.secondary?'巻きぞえ！':id.includes('delivery_van')||id.includes('junction_cabinet')?'どっかーん！':id.includes('market_stall')?'屋台ごと！':id.includes('street_awning')?'ベリッ！':id.includes('crate')?'バラバラ！':type==='glass'||id.startsWith('tank')?'バリン！':type==='wall'||id.startsWith('outer-wall')?'壁、粉砕！':type==='food'?'料理も！':type==='metal'?'ガシャーン！':'バキッ！';feedback('good',label);}
  if(s.burstCount>lastBurstCount){lastBurstCount=s.burstCount;boostUntil=s.time+.9;feedback('good','回転放出！');}
  if((s.rechargeCount||0)>lastReclaimR12){lastReclaimR12=s.rechargeCount;feedback('good','回転 回収！');}
  if(s.ceilingExited&&lastRoofExitAttempt!==s.attempts){lastRoofExitAttempt=s.attempts;feedback('good','天井ぶち抜き！');}
  const accelerating=s.lastBurstGain>0&&s.time<boostUntil;document.body.dataset.accelerating=String(accelerating);$('acceleration').textContent=accelerating?'加速 +'+s.lastBurstGain.toFixed(1)+' m/s':'';$('acceleration').classList.toggle('hidden',!accelerating);
  if(s.earlyMisses>lastMissCount&&!['perfect','good'].includes(s.eventName)){feedback('miss','MISS · 早すぎた');if(s.eventName!=='miss')window.FlightSound.play('miss');}lastMissCount=s.earlyMisses;
  if(s.eventId!==lastEvent){lastEvent=s.eventId;const fx={brace:'kick',perfect:'perfect',good:'good',miss:'miss',land:'land'}[s.eventName];if(fx&&(!Array.isArray(s.events)||fx!=='land')){const kind=fx==='land'?(s.contactKind===1?'shell':s.contactKind===2?'claw':'legs'):fx;window.FlightSound.play(kind,fx==='land'?Math.min(1,Math.max(.2,(s.impactImpulse||0)/18)):1);}if(['perfect','good','miss'].includes(s.eventName))feedback(s.eventName,s.eventName==='perfect'?'PERFECT!':s.eventName==='good'?'GOOD!':'MISS · 早すぎた');}
 }
 const invalid=!!s.physicsFault;document.body.dataset.invalidResult=String(invalid);$('resultTitle').textContent=invalid?'安全停止':s.newRecord?'飛距離 · 新記録！':'飛距離';$('distanceResultUnit').textContent=invalid?'':' m';$('flightSummary').textContent=s.angle+'° · '+(s.direction<0?'左':'右')+' · 勢い '+Math.round(s.power)+' · 最高 '+s.peak.toFixed(1)+' m';
 $('firstContactResult').textContent='粉砕 '+s.destructionEvent+' · 加速 '+s.burstCount+' 回';
 $('resultCause').textContent=s.phase==='result'?'投球終了 · 回転エネルギー残量 '+$('rotorReserve').value+'%':'';
 $('bestDifference').textContent=s.previousBest>0?'ベスト差 '+(s.bestDelta>=0?'+':'')+s.bestDelta.toFixed(1)+' m':'はじめての記録';
 if(invalid){$('resultCause').textContent='物理試作を安全停止。この投球は記録対象外です。';$('firstContactResult').textContent=({'non-finite':'数値異常を検出','floor-tunnel':'地面の貫通を検出','world-bound':'試験範囲の外へ到達','settle-timeout':'停止までの試験時間を超過'})[s.physicsFault]||'物理状態の確認が必要です';$('bestDifference').textContent='入力を変えて再試行できます。旧記録は保持。';}
 if(phase==='result'&&lastResult!==s.attempts){lastResult=s.attempts;settleProgress(s);if(!invalid){savedBest=Math.max(savedBest,s.best);try{localStorage.setItem(RECORD,JSON.stringify({ruleVersion:RULE,best:savedBest,lastRun:{distance:s.distance,firstContact:s.firstContact,perfect:s.perfects,good:s.goods,earlyMiss:s.earlyMisses,config:{...config}}}));}catch{}}}
};
window.CrabCredits.mount({onOpen:()=>{if(view==='title')setPaused(true);},onClose:()=>{if(view==='title')setPaused(false);}});
window.FlightFeel.mount();$('loadAgain').onclick=()=>window.location.reload();numbers();applyComfort();$('best').textContent=savedBest.toFixed(1)+' m';
(async()=>{try{const script=document.createElement('script');script.src='Build/kani-v0.4-route-r29.loader.js';document.body.appendChild(script);await new Promise((resolve,reject)=>{script.onload=resolve;script.onerror=reject;});game=await createUnityInstance($('unity-canvas'),{dataUrl:'Build/kani-v0.4-route-r29.data',frameworkUrl:'Build/kani-v0.4-route-r29.framework.js',codeUrl:'Build/kani-v0.4-route-r29.wasm',streamingAssetsUrl:new URL('StreamingAssets',document.baseURI).href,companyName:'SakiyaPrototype',productName:'カニとばし',productVersion:'kani-v0.4-route-r29',autoSyncPersistentDataPath:true},p=>$('loadText').textContent=Math.round(p*100)+'%');await window.FlightFeel.load();configure();send('RestoreBest',savedBest);applyComfort();loaded=true;$('start').disabled=!runtimeReady;if(runtimeReady)setView('title');else $('loadText').textContent='カニの準備を仕上げています…';}catch(error){setView('error');$('loadTitle').textContent='読み込み失敗 · kani-v0.4-route-r29';$('loadText').textContent='3Dカニを開始できませんでした。再読み込みで戻らない場合は実行環境の確認が必要です。';$('loadAgain').classList.remove('hidden');console.info('Flight load failed:',String(error));}})();
